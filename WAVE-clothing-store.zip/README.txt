# WAVE Clothing Store

A simple responsive clothing-store starter website for T-shirts, hoodies and board shorts.

## Run it
Open `index.html` in a browser.

## Customize
- Change the brand name in `index.html`.
- Replace the product names/prices/images in `script.js`.
- Edit colors and layout in `style.css`.
- The cart uses localStorage, so it stays in the browser.
- The checkout button is a placeholder. A real store needs a payment provider and backend/order system.

## Important
The sample product photos are remote Unsplash images. For your real shop, replace them with your own product photos.
