const products = [
  {id:1,name:"Sunset Logo Tee",category:"tshirt",price:28,image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=900&q=80",tag:"NEW"},
  {id:2,name:"Everyday Heavy Tee",category:"tshirt",price:32,image:"https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=900&q=80"},
  {id:3,name:"Wave Club Hoodie",category:"hoodie",price:58,image:"https://images.unsplash.com/photo-1556821840-3a63f95609a7?auto=format&fit=crop&w=900&q=80",tag:"BESTSELLER"},
  {id:4,name:"Coastal Zip Hoodie",category:"hoodie",price:64,image:"https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=900&q=80"},
  {id:5,name:"Blue Tide Board Shorts",category:"shorts",price:42,image:"https://images.unsplash.com/photo-1560089000-7433a4ebbd64?auto=format&fit=crop&w=900&q=80",tag:"NEW"},
  {id:6,name:"Palm Check Board Shorts",category:"shorts",price:46,image:"https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=900&q=80"}
];

let cart = JSON.parse(localStorage.getItem("waveCart") || "[]");

function renderProducts(list=products){
  document.getElementById("products").innerHTML = list.map(p => `
    <article class="product-card">
      <div class="product-image" style="background-image:url('${p.image}')">
        ${p.tag ? `<span class="tag">${p.tag}</span>` : ""}
      </div>
      <div class="product-info">
        <h3>${p.name}</h3>
        <p>${p.category === "tshirt" ? "T-Shirt" : p.category === "hoodie" ? "Hoodie" : "Board Shorts"}</p>
        <div class="product-row">
          <span class="price">$${p.price.toFixed(2)}</span>
          <button class="add" onclick="addToCart(${p.id})">Add to cart</button>
        </div>
      </div>
    </article>`).join("");
}

function filterProducts(category, btn){
  document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));
  btn.classList.add("active");
  renderProducts(category==="all" ? products : products.filter(p=>p.category===category));
}

function addToCart(id){
  const existing=cart.find(x=>x.id===id);
  if(existing) existing.qty++;
  else cart.push({id,qty:1});
  saveCart(); renderCart(); toggleCart(true);
}

function removeFromCart(id){
  cart=cart.filter(x=>x.id!==id);
  saveCart(); renderCart();
}

function changeQty(id,amount){
  const item=cart.find(x=>x.id===id);
  if(!item)return;
  item.qty+=amount;
  if(item.qty<=0) removeFromCart(id);
  saveCart(); renderCart();
}

function saveCart(){localStorage.setItem("waveCart",JSON.stringify(cart))}
function renderCart(){
  const items=document.getElementById("cartItems");
  const count=cart.reduce((s,x)=>s+x.qty,0);
  document.getElementById("cartCount").textContent=count;
  if(!cart.length){items.innerHTML='<div class="empty">Your cart is empty.</div>';document.getElementById("cartTotal").textContent="$0.00";return}
  let total=0;
  items.innerHTML=cart.map(item=>{
    const p=products.find(x=>x.id===item.id);
    total+=p.price*item.qty;
    return `<div class="cart-item">
      <img src="${p.image}">
      <div class="cart-item-info">
        <h4>${p.name}</h4><div>$${p.price.toFixed(2)}</div>
        <div class="qty">Qty: ${item.qty}
          <button onclick="changeQty(${p.id},1)"> + </button>
          <button onclick="changeQty(${p.id},-1)"> − </button>
        </div>
        <button class="remove" onclick="removeFromCart(${p.id})">Remove</button>
      </div>
    </div>`
  }).join("");
  document.getElementById("cartTotal").textContent="$"+total.toFixed(2);
}
function toggleCart(force){
  const open=force===true || !document.getElementById("cart").classList.contains("open");
  document.getElementById("cart").classList.toggle("open",open);
  document.getElementById("overlay").classList.toggle("open",open);
}
function checkout(){
  if(!cart.length){alert("Your cart is empty.");return}
  alert("Checkout is ready to connect to Stripe, PayPal, or your preferred payment system.");
}
renderProducts();renderCart();
